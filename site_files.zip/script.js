// آپلود فایل (شبیه‌سازی)
function uploadFile() {
    const fileInput = document.getElementById('file-upload');
    if (fileInput.files.length > 0) {
        alert('فایل ' + fileInput.files[0].name + ' آپلود شد!');
    } else {
        alert('لطفاً یک فایل انتخاب کنید.');
    }
}
// چت (شبیه‌سازی ساده)
function sendMessage() {
    const chatInput = document.getElementById('chat-input');
    const chatBox = document.getElementById('chat-box');
    if (chatInput.value.trim() !== '') {
        const message = document.createElement('p');
        message.textContent = 'داوطلب: ' + chatInput.value;
        chatBox.appendChild(message);
        chatBox.scrollTop = chatBox.scrollHeight;
        chatInput.value = '';
        setTimeout(() => {
            const reply = document.createElement('p');
            reply.textContent = 'مشاور: ممنون، پیام شما دریافت شد!';
            chatBox.appendChild(reply);
            chatBox.scrollTop = chatBox.scrollHeight;
        }, 1000);
    }
}
// تقویم (شبیه‌سازی افزودن رویداد)
function addEvent() {
    const eventTitle = document.getElementById('event-title').value;
    const eventDate = document.getElementById('event-date').value;
    const calendar = document.getElementById('calendar');
    if (eventTitle && eventDate) {
        const event = document.createElement('p');
        event.textContent = `${eventTitle} - ${eventDate}`;
        calendar.appendChild(event);
        document.getElementById('event-title').value = '';
        document.getElementById('event-date').value = '';
    } else {
        alert('لطفاً عنوان و تاریخ رویداد را وارد کنید.');
    }
}
